/*
 * package tests;
 * 
 * import static org.junit.Assert.*;
 * 
 * import org.junit.Test;
 * 
 * import chronos.Person; import chronos.Person.Status;
 * 
 * public class PersonTest {
 * 
 * @Test public void personStructTest() { Person person = new Person("username",
 * "name", 1); assertEquals(person.getUsername(), "username");
 * assertEquals(person.getName(),"name"); assertEquals(person.getStatus(),
 * Status.REJECTED); } }
 */
package tests;

public class CalendarModelTest {
	public static void main(String[] args) {
	}

}

A simple calendar application!
